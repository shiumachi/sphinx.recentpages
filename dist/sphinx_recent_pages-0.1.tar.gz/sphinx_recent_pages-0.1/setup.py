from setuptools import setup
setup(name='sphinx_recent_pages',
      version='0.1',
      author='Sho Shimauchi',
      author_email='sho.shimauchi@gmail.com'
      )
